export const consoleLogHelper = () => {
  console.log('Im helper! From utils.js');
}

export const consoleLogHelper2 = () => {
  console.log('Im helper number 2! From utils.js');
}